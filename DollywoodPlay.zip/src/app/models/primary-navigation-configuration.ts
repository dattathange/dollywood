export class primaryNavigationOrientationData {

    name: string;
    title: string;
    label: string;
    is_visible: string;
    description: string;
    header_or_burger: string;
    is_carousal: boolean;
    image: string
}