import {geoMapping} from './geo-mapping'
export class geoData{
    name: string;
    lat: string;
    lng: string;
    geoMapping: geoMapping[];

}
