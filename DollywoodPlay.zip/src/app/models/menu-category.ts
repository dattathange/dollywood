export class MenuCategory
{
    
}