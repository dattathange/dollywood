export class pageCategoryOrientation {
    name: string;
    title: string;
    label: string;
    description: string;
    is_visible: boolean;
    image: string;
    caption: string;
    is_button: string;
    click_through: string;
    display_indexing: number;
    carousal_type: string;
}