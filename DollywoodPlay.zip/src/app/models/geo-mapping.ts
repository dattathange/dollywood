export class geoMapping {
    country: string;
    state: string;
    city: string;
}