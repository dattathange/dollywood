export class BitmovinResult
{
    public bitmovin_key: string;
    public bitmovin_analytics_key: string;
}