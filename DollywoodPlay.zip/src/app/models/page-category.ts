import { PageCategoryContent } from './page-category-content';

export class PageCategory {
    public status: string;
    public type: string;
    public content: PageCategoryContent[];
    public data: any;
    public display_type: string;
    
}