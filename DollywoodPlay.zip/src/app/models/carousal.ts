import {pageCategoryOrientation} from './page-category-orientation'

export class carousal {
    device: string;
    same_for_all_orientation: string;
    path: string;
    type: string;
    orientation: pageCategoryOrientation[];
}