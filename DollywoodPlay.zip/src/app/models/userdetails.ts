export class UserDetails
{
    
    public userId: string;
    public name: string;
    
}