export class navigationClickData {
    path: string;
    type: string;
    alias: string;
    constructor() {};
}