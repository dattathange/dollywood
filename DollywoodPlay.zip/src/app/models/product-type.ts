export class productType{
    name: string;
}