import {primaryNavigationOrientationData} from './primary-navigation-configuration'
export class primaryNavigationData {
    device: string;
    same_for_all_orientation: string;
    primaryNavigationOrientationData: primaryNavigationOrientationData[];
    order_by: string;
    sorting: string;
    display_indexing: number

}