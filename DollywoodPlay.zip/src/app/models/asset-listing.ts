import { AssetData } from './asset-data';

export class AssetListing {
    public status: boolean;
    public data: AssetData[];
}